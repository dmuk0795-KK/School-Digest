"""AWS Lambda entry point.

Set the function's handler to ``digest_school.lambda_handler.handler``.
See README.md ("Hosting on AWS Lambda").
"""

import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "digest_school.settings")

from mangum import Mangum  # noqa: E402

from digest_school.asgi import application  # noqa: E402

# Django's ASGI handler does not implement the lifespan protocol.
asgi_handler = Mangum(application, lifespan="off")


def with_trailing_slash(path: str) -> str:
    """Every page address ends in a slash; only static files (which have an extension) do not."""
    if path.endswith("/") or "." in path.rsplit("/", 1)[-1]:
        return path
    return path + "/"


def handler(event, context):
    # A Function URL drops the trailing slash from the path Mangum reads, which
    # would send every page into a redirect loop as Django tries to add it back.
    http = event.get("requestContext", {}).get("http")
    if http and "path" in http:
        http["path"] = with_trailing_slash(event.get("rawPath") or http["path"])
    return asgi_handler(event, context)
