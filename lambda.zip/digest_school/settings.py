"""Settings for the Digest School frontend prototype.

This phase is UI only, so there is deliberately no database, no auth and no
sessions. See README.md ("Adding a backend later") for what to switch on.
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Development defaults. Set real values through the environment before deploying.
SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "dev-only-key-replace-before-deploying")
DEBUG = os.environ.get("DJANGO_DEBUG", "1") == "1"
ALLOWED_HOSTS = [
    host.strip()
    for host in os.environ.get("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1,[::1]").split(",")
    if host.strip()
]

INSTALLED_APPS = [
    "django.contrib.staticfiles",
    "digest",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    # Serves the collected static files when debug is off (see README, "Hosting on AWS Lambda").
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "digest_school.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "digest.context_processors.site",
            ],
        },
    },
]

WSGI_APPLICATION = "digest_school.wsgi.application"

# No database in this phase: all content comes from digest/data/*.json.
DATABASES = {}

LANGUAGE_CODE = "en-gb"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# HTMX powers three small enhancements (live search suggestions, category
# filters without a page reload, and the newsletter form). Every one of them
# also works as a plain link or form, so the site is fully usable without it.
#
# If static/vendor/htmx.min.js exists it is served locally; otherwise the
# pinned CDN build below is used. See README.md ("Serving HTMX locally").
HTMX_VERSION = "2.0.4"
HTMX_LOCAL_PATH = "vendor/htmx.min.js"
HTMX_CDN_URL = f"https://unpkg.com/htmx.org@{HTMX_VERSION}/dist/htmx.min.js"
