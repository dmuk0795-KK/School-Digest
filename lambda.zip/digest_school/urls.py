from django.urls import include, path

urlpatterns = [
    path("", include("digest.urls")),
]

# Used when DEBUG is False. In development the catch-all route at the end of
# digest/urls.py shows the same page, so the custom 404 is always visible.
handler404 = "digest.views.page_not_found"
