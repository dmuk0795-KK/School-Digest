from django.urls import path, re_path

from . import views

app_name = "digest"

urlpatterns = [
    path("", views.home, name="home"),
    path("stories/", views.stories, name="stories"),
    path("category/<slug:slug>/", views.category, name="category"),
    path("digest/<slug:slug>/", views.article, name="article"),
    path("search/", views.search, name="search"),
    path("search/suggest/", views.search_suggest, name="search_suggest"),
    path("newsletter/", views.newsletter, name="newsletter"),
    path("about/", views.about, name="about"),
    path("editorial-policy/", views.editorial_policy, name="editorial_policy"),
    path("contact/", views.info_page, {"slug": "contact"}, name="contact"),
    path("privacy/", views.info_page, {"slug": "privacy"}, name="privacy"),
    path("terms/", views.info_page, {"slug": "terms"}, name="terms"),
    # Keep this last: anything unmatched gets the custom 404 page.
    re_path(r"^(?P<unmatched>.*)$", views.fallback, name="fallback"),
]
