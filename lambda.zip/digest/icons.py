"""Inline SVG icons, drawn on a 24 x 24 grid with a 2px rounded stroke.

Kept in one place so every icon on the site shares the same weight and style.
Use them in templates with the `icon` tag:

    {% load digest_extras %}
    {% icon "search" css="size-5" %}
"""

ICONS = {
    # Interface
    "search": '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>',
    "menu": '<path d="M4 7h16M4 12h16M4 17h16"/>',
    "close": '<path d="M6 6l12 12M18 6 6 18"/>',
    "sun": '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/>',
    "moon": '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5Z"/>',
    "arrow-right": '<path d="M5 12h14M13 6l6 6-6 6"/>',
    "arrow-up-right": '<path d="M7 17 17 7M8 7h9v9"/>',
    "chevron-right": '<path d="m9 6 6 6-6 6"/>',
    "chevron-left": '<path d="m15 6-6 6 6 6"/>',
    "clock": '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    "calendar": '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    "mail": '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m3.5 7.5 8.5 6 8.5-6"/>',
    "check": '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
    "check-circle": '<circle cx="12" cy="12" r="8.5"/><path d="m8 12.3 2.8 2.8L16 9.5"/>',
    "alert": '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5v5M12 16v.3"/>',
    "info": '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.7V8"/>',
    "lightbulb": '<path d="M9 17.5h6M10 20.5h4M8.2 14.3A6 6 0 1 1 15.8 14.3c-.6.6-.8 1.2-.8 2v1.2H9v-1.2c0-.8-.2-1.4-.8-2Z"/>',
    "link": '<path d="M10 14a4 4 0 0 0 5.7 0l3-3A4 4 0 0 0 13 5.3l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3A4 4 0 0 0 11 18.7l1-1"/>',
    "text-size": '<path d="M3 18 7.5 7h1L13 18M4.6 14.5h6.8M14.5 18l3-7.5h.5l3 7.5M15.6 15.5h4.3"/>',
    "book": '<path d="M12 6.5C10 5 7 4.5 3.5 5v13c3.5-.5 6.5 0 8.5 1.5 2-1.5 5-2 8.5-1.5V5C17 4.5 14 5 12 6.5ZM12 6.5V19.5"/>',
    "bolt": '<path d="M13 2.5 5 13.5h6l-1 8 8-11h-6l1-8Z"/>',
    "flame": '<path d="M12 21a6.5 6.5 0 0 0 6.5-6.5c0-3-2-5-3-7-.5 1.5-1.5 2.5-2.5 3 0-3-1.5-6-4-7.5.3 3-1 4.5-2.2 6.3A7.3 7.3 0 0 0 5.5 14.5 6.5 6.5 0 0 0 12 21Z"/>',
    "list": '<path d="M9 6.5h11M9 12h11M9 17.5h11M4.5 6.5h.01M4.5 12h.01M4.5 17.5h.01"/>',
    "home": '<path d="M4 11 12 4l8 7v8.5a1 1 0 0 1-1 1h-4.5v-6h-5v6H5a1 1 0 0 1-1-1V11Z"/>',
    # Categories
    "globe": '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.5 3.7 5.3 3.7 8.5s-1.2 6-3.7 8.5c-2.5-2.5-3.7-5.3-3.7-8.5s1.2-6 3.7-8.5Z"/>',
    "landmark": '<path d="M3.5 9.5 12 4l8.5 5.5M5 9.5h14M6.5 12.5v5M10.2 12.5v5M13.8 12.5v5M17.5 12.5v5M4 20.5h16"/>',
    "chart": '<path d="M4 20.5h16M7 17v-4M12 17V9M17 17V6"/>',
    "chip": '<rect x="6.5" y="6.5" width="11" height="11" rx="2"/><rect x="10" y="10" width="4" height="4" rx=".5"/><path d="M9.5 3.5v3M14.5 3.5v3M9.5 17.5v3M14.5 17.5v3M3.5 9.5h3M3.5 14.5h3M17.5 9.5h3M17.5 14.5h3"/>',
    "atom": '<circle cx="12" cy="12" r="1.3"/><ellipse cx="12" cy="12" rx="9" ry="3.7"/><ellipse cx="12" cy="12" rx="9" ry="3.7" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9" ry="3.7" transform="rotate(120 12 12)"/>',
    "heart": '<path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.3a4.3 4.3 0 0 1 7.5 2.5C19.5 15.4 12 20 12 20Z"/>',
    "leaf": '<path d="M5 19c0-8 5-13 15-14 0 10-5 15-13 15M5 19c2-4 5-7 9-9"/>',
    "cap": '<path d="m2.5 9.5 9.5-4.5 9.5 4.5-9.5 4.5-9.5-4.5ZM6.5 11.7v4.3c1.5 1.5 3.3 2.2 5.5 2.2s4-.7 5.5-2.2v-4.3M21.5 9.5v5"/>',
    "trophy": '<path d="M8 4.5h8v5a4 4 0 0 1-8 0v-5ZM8 6.5H4.5c0 2.5 1.2 4 3.7 4.3M16 6.5h3.5c0 2.5-1.2 4-3.7 4.3M12 13.5v4M8.5 20.5h7M10 17.5h4"/>',
    # Social placeholders
    "social-x": '<path d="M5 4.5 19 19.5M19 4.5 5 19.5"/>',
    "social-facebook": '<path d="M14.5 8.5V7c0-1 .5-1.5 1.5-1.5h1.5v-3H15c-2.5 0-4 1.5-4 4v2H8.5v3H11v8.5h3.5V11.5h2.5l.5-3h-3Z"/>',
    "social-youtube": '<rect x="3" y="6" width="18" height="12" rx="3.5"/><path d="m10.5 9.5 4 2.5-4 2.5v-5Z"/>',
    "social-linkedin": '<rect x="3.5" y="3.5" width="17" height="17" rx="2.5"/><path d="M8 10.5v6M8 7.5v.01M12 16.5v-6M12 13c0-1.5 1-2.5 2.2-2.5S16 11.5 16 13v3.5"/>',
    "social-rss": '<path d="M5 5c8 0 14 6 14 14M5 11c4.5 0 8 3.5 8 8"/><circle cx="6" cy="18" r="1.2"/>',
}
