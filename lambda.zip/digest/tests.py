"""Smoke tests for the Digest School prototype.

Run them with:  python manage.py test

They need no database (the project has none): every test is a SimpleTestCase
that asks the site for a page and checks what comes back.
"""

from django.test import SimpleTestCase
from django.urls import reverse

from . import content


class PageTests(SimpleTestCase):
    def test_every_named_page_loads(self):
        for name in ("home", "stories", "search", "newsletter", "about",
                     "editorial_policy", "contact", "privacy", "terms"):
            with self.subTest(page=name):
                response = self.client.get(reverse(f"digest:{name}"))
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, "Digest School")

    def test_every_category_page_loads(self):
        for category in content.all_categories():
            with self.subTest(category=category.slug):
                response = self.client.get(reverse("digest:category", args=[category.slug]))
                self.assertContains(response, category.description)

    def test_every_article_page_loads(self):
        for story in content.all_stories():
            with self.subTest(story=story.slug):
                response = self.client.get(reverse("digest:article", args=[story.slug]))
                self.assertContains(response, story.title)
                self.assertContains(response, "Key takeaways")
                self.assertContains(response, "What is established")
                self.assertContains(response, "Our reading")
                self.assertContains(response, "Sample digest")

    def test_homepage_sections(self):
        response = self.client.get(reverse("digest:home"))
        for text in ("The world, made clearer.", "Explore categories", "Today’s Digest",
                     "Quick Reads", "Why It Matters", "Trending Now", "Sample ranking",
                     "Join the Digest School newsletter", "Learn. Explore. Grow."):
            with self.subTest(text=text):
                self.assertContains(response, text.replace("’", "&rsquo;") if "’" in text else text)
        self.assertContains(response, content.featured().title)

    def test_every_cover_image_exists(self):
        from django.contrib.staticfiles import finders
        for story in content.all_stories():
            with self.subTest(story=story.slug):
                self.assertIsNotNone(finders.find(story.image), f"missing {story.image}")


class NotFoundTests(SimpleTestCase):
    def test_unknown_urls_use_the_custom_404(self):
        for url in ("/no-such-page/", "/digest/no-such-story/", "/category/no-such-category/"):
            with self.subTest(url=url):
                response = self.client.get(url)
                self.assertEqual(response.status_code, 404)
                self.assertContains(response, "This page is not in our library", status_code=404)

    def test_missing_trailing_slash_redirects(self):
        response = self.client.get("/about")
        self.assertRedirects(response, "/about/", status_code=301)
        response = self.client.get("/search?q=ai")
        self.assertRedirects(response, "/search/?q=ai", status_code=301)

    def test_read_only_pages_refuse_post(self):
        self.assertEqual(self.client.post(reverse("digest:home")).status_code, 405)


class SearchTests(SimpleTestCase):
    def test_popular_topics_all_find_something(self):
        for topic in content.popular_topics():
            with self.subTest(topic=topic):
                self.assertTrue(content.search(topic), f"no results for {topic!r}")

    def test_short_terms_match_whole_words_only(self):
        slugs = [story.slug for story in content.search("AI")]
        self.assertEqual(slugs, ["ai-study-habits"])

    def test_results_page(self):
        response = self.client.get(reverse("digest:search"), {"q": "frog"})
        self.assertContains(response, "1 result for")
        self.assertContains(response, "<mark>frog</mark>", html=False)

    def test_results_can_be_filtered_by_category(self):
        response = self.client.get(reverse("digest:search"), {"q": "climate change", "category": "world"})
        self.assertContains(response, "1 result for")
        self.assertContains(response, "Coastal cities swap notes")
        self.assertNotContains(response, "Street trees can cool")

    def test_empty_states(self):
        self.assertContains(self.client.get(reverse("digest:search")), "Not sure where to start?")
        self.assertContains(self.client.get(reverse("digest:search"), {"q": "zzzz"}), "No digests match")

    def test_query_is_escaped(self):
        response = self.client.get(reverse("digest:search"), {"q": "<script>alert(1)</script>"})
        self.assertNotContains(response, "<script>alert(1)</script>")

    def test_suggestions_partial(self):
        response = self.client.get(reverse("digest:search_suggest"), {"q": "clim"})
        self.assertContains(response, "Clean energy")
        self.assertNotContains(response, "<html")
        self.assertEqual(self.client.get(reverse("digest:search_suggest"), {"q": "c"}).content.strip(), b"")


class CategoryFilterTests(SimpleTestCase):
    def test_all_stories(self):
        response = self.client.get(reverse("digest:stories"))
        self.assertContains(response, f"Showing {len(content.all_stories())} digests")

    def test_filtered(self):
        response = self.client.get(reverse("digest:stories"), {"category": "science"})
        self.assertContains(response, "Showing 3 digests")
        self.assertContains(response, "A space telescope maps a nursery of young stars")
        self.assertNotContains(response, "Markets steady as price rises slow")

    def test_unknown_category_shows_everything(self):
        response = self.client.get(reverse("digest:stories"), {"category": "nope"})
        self.assertContains(response, f"Showing {len(content.all_stories())} digests")


class NewsletterTests(SimpleTestCase):
    url = "/newsletter/"

    def test_empty_address(self):
        self.assertContains(self.client.post(self.url, {"email": ""}), "Enter your email address.")

    def test_invalid_address_is_kept_in_the_field(self):
        response = self.client.post(self.url, {"email": "not-an-email"})
        self.assertContains(response, "That does not look like an email address")
        self.assertContains(response, 'value="not-an-email"')

    def test_valid_address_shows_demo_confirmation(self):
        response = self.client.post(self.url, {"email": "reader@example.com"})
        self.assertContains(response, "Subscribed (demo)")
        self.assertContains(response, "Nothing was stored")

    def test_htmx_requests_get_only_the_form(self):
        response = self.client.post(self.url, {"email": "reader@example.com"}, HTTP_HX_REQUEST="true")
        self.assertContains(response, "Subscribed (demo)")
        self.assertNotContains(response, "<html")
        self.assertTrue(response.content.strip().startswith(b'<div id="newsletter-panel">'))


class ContentTests(SimpleTestCase):
    """The sample data should stay complete enough for every template."""

    def test_each_category_has_stories(self):
        for facet in content.category_counts():
            with self.subTest(category=facet["category"].slug):
                self.assertGreaterEqual(facet["count"], 1)

    def test_stories_are_complete(self):
        for story in content.all_stories():
            with self.subTest(story=story.slug):
                self.assertGreaterEqual(len(story.takeaways), 3)
                self.assertGreaterEqual(len(story.why.established), 1)
                self.assertTrue(story.why.interpretation)
                self.assertTrue(story.background)
                self.assertTrue(story.image_alt)
                self.assertLessEqual(story.read_minutes, 5)

    def test_related_stories_exclude_the_story_itself(self):
        story = content.featured()
        self.assertNotIn(story, content.related_to(story))
