"""Template helpers for Digest School: inline icons and search highlighting."""

import re

from django import template
from django.utils.html import conditional_escape, format_html
from django.utils.safestring import mark_safe

from ..content import search_terms, term_pattern
from ..icons import ICONS

register = template.Library()


@register.simple_tag
def icon(name, css="size-5", label=""):
    """Render an inline SVG icon.

    Icons are decorative by default (hidden from screen readers). Pass `label`
    only when the icon is the sole content of a control and needs a name.
    """
    shapes = ICONS.get(name)
    if shapes is None:
        return ""
    if label:
        accessibility = format_html('role="img" aria-label="{}"', label)
    else:
        accessibility = mark_safe('aria-hidden="true"')
    return format_html(
        '<svg class="{}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
        'stroke-linecap="round" stroke-linejoin="round" focusable="false" {}>{}</svg>',
        css,
        accessibility,
        mark_safe(shapes),
    )


@register.filter
def highlight(text, query):
    """Wrap the words of `query` in <mark> wherever they start a word in `text`."""
    text = str(text)
    terms = search_terms(str(query or ""))
    if not terms:
        return conditional_escape(text)

    combined = re.compile("|".join(term_pattern(term).pattern for term in terms), re.IGNORECASE)
    pieces = []
    position = 0
    for match in combined.finditer(text):
        # Extend the match to the end of the word, so "clim" marks "climate".
        end = match.end()
        while end < len(text) and (text[end].isalnum() or text[end] in "’'"):
            end += 1
        if match.start() < position:
            continue
        pieces.append(conditional_escape(text[position:match.start()]))
        pieces.append(format_html("<mark>{}</mark>", text[match.start():end]))
        position = end
    pieces.append(conditional_escape(text[position:]))
    return mark_safe("".join(pieces))


@register.filter
def minutes(value):
    """1 -> "1 min read", 4 -> "4 min read"."""
    return f"{value} min read"
