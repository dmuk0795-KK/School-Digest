"""Values every template needs: site details, navigation and asset locations."""

from datetime import date
from functools import lru_cache

from django.conf import settings
from django.contrib.staticfiles import finders
from django.templatetags.static import static
from django.urls import reverse

from . import content


@lru_cache(maxsize=1)
def htmx_src() -> str:
    """Serve HTMX from static/vendor/ when it has been downloaded, else the CDN."""
    if finders.find(settings.HTMX_LOCAL_PATH):
        return static(settings.HTMX_LOCAL_PATH)
    return settings.HTMX_CDN_URL


def site(request):
    details = content.site()
    return {
        "site": details,
        "nav_categories": content.all_categories(),
        "popular_topics": content.popular_topics(),
        "footer_links": [
            {"label": link["label"], "url": reverse(f"digest:{link['route']}")}
            for link in details["footer_links"]
        ],
        "current_year": date.today().year,
        "htmx_src": htmx_src(),
    }
