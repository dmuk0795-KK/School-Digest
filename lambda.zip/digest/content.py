"""Read-only access to the prototype's sample content.

Everything the templates show comes through the functions in this module, and
this module is the only place that knows the content lives in JSON files.
When a real backend arrives, re-implement these functions on top of models or
an API and the views and templates can stay as they are.

Nothing here imports Django, so the data layer can be tested on its own.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "data"

# Words that add nothing to a search and would otherwise match almost everything.
STOP_WORDS = frozenset({"a", "an", "and", "at", "for", "in", "is", "of", "on", "or", "the", "to"})


@dataclass(frozen=True)
class Category:
    slug: str
    name: str
    icon: str
    tagline: str
    description: str


@dataclass(frozen=True)
class Publisher:
    slug: str
    name: str


@dataclass(frozen=True)
class WhyItMatters:
    title: str
    established: tuple[str, ...]
    interpretation: str


@dataclass(frozen=True)
class Story:
    slug: str
    title: str
    category: Category
    publisher: Publisher
    days_ago: int
    read_minutes: int
    art: str
    image_alt: str
    summary: str
    tags: tuple[str, ...]
    takeaways: tuple[str, ...]
    why: WhyItMatters
    background: tuple[str, ...]
    source_url: str | None

    @property
    def image(self) -> str:
        """Path of the cover image, relative to the static root."""
        return f"img/covers/{self.art}.svg"

    @property
    def published(self) -> date:
        """Sample dates are stored as "days ago" so the demo never looks stale."""
        return date.today() - timedelta(days=self.days_ago)


def _read(name: str):
    with (DATA_DIR / name).open(encoding="utf-8") as handle:
        return json.load(handle)


@lru_cache(maxsize=None)
def _library() -> dict:
    """Load and link every JSON file once per process."""
    categories = {item["slug"]: Category(**item) for item in _read("categories.json")}
    publishers = {item["slug"]: Publisher(**item) for item in _read("publishers.json")}

    stories = {}
    for item in _read("stories.json"):
        why = item["why"]
        stories[item["slug"]] = Story(
            slug=item["slug"],
            title=item["title"],
            category=categories[item["category"]],
            publisher=publishers[item["publisher"]],
            days_ago=item["days_ago"],
            read_minutes=item["read_minutes"],
            art=item["art"],
            image_alt=item["image_alt"],
            summary=item["summary"],
            tags=tuple(item["tags"]),
            takeaways=tuple(item["takeaways"]),
            why=WhyItMatters(
                title=why["title"],
                established=tuple(why["established"]),
                interpretation=why["interpretation"],
            ),
            background=tuple(item["background"]),
            source_url=item.get("source_url"),
        )

    return {
        "categories": categories,
        "publishers": publishers,
        "stories": stories,
        "home": _read("home.json"),
        "pages": _read("pages.json"),
        "site": _read("site.json"),
    }


# -- Site ------------------------------------------------------------------

def site() -> dict:
    return _library()["site"]


def page(slug: str) -> dict | None:
    return _library()["pages"].get(slug)


# -- Categories ------------------------------------------------------------

def all_categories() -> list[Category]:
    return list(_library()["categories"].values())


def get_category(slug: str) -> Category | None:
    return _library()["categories"].get(slug)


# -- Stories ---------------------------------------------------------------

def all_stories() -> list[Story]:
    """Every story, newest first."""
    return sorted(_library()["stories"].values(), key=lambda story: (story.days_ago, story.title))


def get_story(slug: str) -> Story | None:
    return _library()["stories"].get(slug)


def stories_in(category_slug: str) -> list[Story]:
    return [story for story in all_stories() if story.category.slug == category_slug]


def category_counts(stories: list[Story] | None = None) -> list[dict]:
    """Each category with the number of stories it has in `stories`."""
    stories = all_stories() if stories is None else stories
    counts: dict[str, int] = {}
    for story in stories:
        counts[story.category.slug] = counts.get(story.category.slug, 0) + 1
    return [{"category": category, "count": counts.get(category.slug, 0)} for category in all_categories()]


def related_to(story: Story, limit: int = 3) -> list[Story]:
    """Stories from the same category first, then ones that share a tag."""
    others = [other for other in all_stories() if other.slug != story.slug]
    same_category = [other for other in others if other.category == story.category]
    shared_tag = [
        other for other in others
        if other.category != story.category and set(other.tags) & set(story.tags)
    ]
    return (same_category + shared_tag)[:limit]


# -- Homepage curation -----------------------------------------------------

def _pick(key: str) -> list[Story]:
    stories = _library()["stories"]
    return [stories[slug] for slug in _library()["home"][key] if slug in stories]


def featured() -> Story:
    return _library()["stories"][_library()["home"]["featured"]]


def todays_digest() -> list[Story]:
    return _pick("today")


def quick_reads() -> list[Story]:
    return _pick("quick_reads")


def why_it_matters() -> list[Story]:
    return _pick("why_it_matters")


def trending() -> list[Story]:
    """A hand-picked sample list. Replace with real readership data later."""
    return _pick("trending")


def popular_topics() -> list[str]:
    return list(_library()["home"]["popular_topics"])


# -- Search ----------------------------------------------------------------

def search_terms(query: str) -> list[str]:
    """Split a query into lower-case words, dropping filler words."""
    words = re.findall(r"[\w’'-]+", query.lower())
    useful = [word for word in words if word not in STOP_WORDS]
    return useful or words


def term_pattern(term: str) -> re.Pattern:
    """Match a term at the start of a word. Very short terms must match exactly,
    so that searching "AI" does not match "air" or "aim"."""
    if len(term) <= 2:
        return re.compile(rf"\b{re.escape(term)}\b", re.IGNORECASE)
    return re.compile(rf"\b{re.escape(term)}", re.IGNORECASE)


def search(query: str, category_slug: str = "") -> list[Story]:
    """Stories whose headline, summary, tags, category or publisher match every
    word in `query`, best match first."""
    terms = search_terms(query)
    if not terms:
        return []

    scored = []
    for story in all_stories():
        fields = (
            (story.title, 6),
            (" ".join(story.tags), 4),
            (story.category.name, 3),
            (story.summary, 2),
            (story.publisher.name, 1),
        )
        score = 0
        for term in terms:
            pattern = term_pattern(term)
            hits = [weight for text, weight in fields if pattern.search(text)]
            if not hits:
                score = 0
                break
            score += sum(hits)
        if score:
            scored.append((score, story))

    scored.sort(key=lambda pair: (-pair[0], pair[1].days_ago, pair[1].title))
    results = [story for _, story in scored]
    if category_slug:
        results = [story for story in results if story.category.slug == category_slug]
    return results
