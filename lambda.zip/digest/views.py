"""Views for the Digest School prototype.

Each view gathers sample content from `digest.content` and hands it to a
template. There is no database access anywhere in this file.
"""

from datetime import date

from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.shortcuts import redirect, render
from django.urls import Resolver404, resolve, reverse
from django.utils.http import urlencode
from django.views.decorators.http import require_http_methods, require_safe

from . import content

SUGGESTION_LIMIT = 5
MIN_SUGGEST_LENGTH = 2


def is_htmx(request) -> bool:
    return request.headers.get("HX-Request") == "true"


# -- Pages -----------------------------------------------------------------

@require_safe
def home(request):
    return render(request, "home.html", {
        "active": "home",
        "today": date.today(),
        "hero": content.site()["hero"],
        "featured": content.featured(),
        "todays_digest": content.todays_digest(),
        "quick_reads": content.quick_reads(),
        "why_cards": content.why_it_matters(),
        "trending": content.trending(),
    })


@require_safe
def stories(request):
    """Every digest, with an optional ?category= filter."""
    selected = content.get_category(request.GET.get("category", ""))
    everything = content.all_stories()
    shown = content.stories_in(selected.slug) if selected else everything
    return render(request, "stories.html", {
        "active": "stories",
        "selected": selected,
        "stories": shown,
        "total": len(everything),
        "facets": content.category_counts(everything),
        "filter_base": reverse("digest:stories"),
        "filter_joiner": "?",
    })


@require_safe
def category(request, slug):
    current = content.get_category(slug)
    if current is None:
        return page_not_found(request)
    in_category = content.stories_in(slug)
    elsewhere = [story for story in content.all_stories() if story.category != current]
    return render(request, "category.html", {
        "active": current.slug,
        "category": current,
        "lead": in_category[0] if in_category else None,
        "stories": in_category[1:],
        "count": len(in_category),
        "elsewhere": elsewhere[:3],
    })


@require_safe
def article(request, slug):
    story = content.get_story(slug)
    if story is None:
        return page_not_found(request)
    return render(request, "article.html", {
        "active": story.category.slug,
        "story": story,
        "related": content.related_to(story),
    })


@require_safe
def search(request):
    query = " ".join(request.GET.get("q", "").split())
    selected = content.get_category(request.GET.get("category", ""))
    matches = content.search(query) if query else []
    shown = [story for story in matches if story.category == selected] if selected else matches
    facets = [facet for facet in content.category_counts(matches) if facet["count"]]
    return render(request, "search.html", {
        "active": "search",
        "query": query,
        "selected": selected,
        "results": shown,
        "total": len(matches),
        "facets": facets,
        "filter_base": f"{reverse('digest:search')}?{urlencode({'q': query})}",
        "filter_joiner": "&",
    })


@require_safe
def search_suggest(request):
    """Live suggestions for the search dialog (requested by HTMX as you type)."""
    query = " ".join(request.GET.get("q", "").split())
    matches = content.search(query) if len(query) >= MIN_SUGGEST_LENGTH else []
    return render(request, "partials/suggestions.html", {
        "query": query,
        "suggestions": matches[:SUGGESTION_LIMIT],
        "total": len(matches),
        "too_short": len(query) < MIN_SUGGEST_LENGTH,
    })


@require_http_methods(["GET", "HEAD", "POST"])
def newsletter(request):
    """Demo newsletter sign-up: validates the address, then discards it.

    Nothing is stored and nothing is sent. Replace the marked line with a real
    subscription call when a backend exists.
    """
    context = {"active": "newsletter", "email": "", "error": "", "subscribed": False}

    if request.method == "POST":
        email = request.POST.get("email", "").strip()
        context["email"] = email
        if not email:
            context["error"] = "Enter your email address."
        else:
            try:
                validate_email(email)
            except ValidationError:
                context["error"] = "That does not look like an email address. Check for a missing @ or a typo."
            else:
                # Backend hook: subscribe `email` here. The prototype does nothing with it.
                context["subscribed"] = True

    template = "partials/newsletter_form.html" if is_htmx(request) else "newsletter.html"
    return render(request, template, context)


@require_safe
def about(request):
    return render(request, "about.html", {"active": "about", "page": content.page("about")})


@require_safe
def editorial_policy(request):
    return render(request, "editorial_policy.html", {
        "active": "editorial-policy",
        "page": content.page("editorial-policy"),
    })


@require_safe
def info_page(request, slug):
    """Contact, Privacy and Terms share one simple template."""
    page = content.page(slug)
    if page is None:
        return page_not_found(request)
    return render(request, "page.html", {"active": slug, "page": page})


# -- Not found ---------------------------------------------------------------

def page_not_found(request, exception=None):
    return render(request, "404.html", {"active": ""}, status=404)


def fallback(request, unmatched=""):
    """Catch-all route, so the custom 404 also shows while DEBUG is on.

    Because this route matches everything, Django's usual "add the missing
    trailing slash" redirect never fires. Do that here instead.
    """
    if not request.path_info.endswith("/"):
        try:
            match = resolve(request.path_info + "/")
        except Resolver404:
            match = None
        if match is not None and match.url_name != "fallback":
            return redirect(request.get_full_path(force_append_slash=True), permanent=True)
    return page_not_found(request)
